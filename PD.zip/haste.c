//Corte de hastes

#include<stdio.h>

#define N 10
int p[] ={0,1,5,8,9,10,17,17};
int rm[N];
int state = 1;
char resp = '\0';

int max(int v1, int v2){
	if(v1<=v2){
		return v2;
	}
	else{
		return v1;
	}
}

int BottomUpCutRod(int *p, int n){
	int i,j,q,r[N];

	r[0] = 0;
	for(j=1;j<=n;j++){
		q = -1;
		for(i=1;i<=j;i++){
			q = max(q, p[i] + r[j-i]);
		}
		r[j]=q;
	}
	return r[n];
}

void main(){
	while(state == 1){
		int tam, receita;
		printf("Insira o tamanho\n");
		scanf("%d",&tam);

		receita = BottomUpCutRod(p,tam);

		printf("A receita maxima vai ser %d\n", receita);

		printf("Quer continuar calculando?\n");
		scanf("%*c%c",&resp);
		if(resp == 'n'){
			state = 0;
		}
	}
}